// ==============================================================================
// Nutrient Earth — Supabase Auth & Protected Routes Verification Test Suite
// Verifies:
// 1. Reactive Supabase Auth Providers (currentUser, isAuthenticated, authStateChanges).
// 2. Protected route gating: Unauthenticated requests to /onboarding/* redirect to /auth.
// 3. ReturnTo preservation for post-authentication deep linking.
// 4. Authenticated sessions bypass login and redirect forward.
// 5. Password recovery and password update methods.
// ==============================================================================

import 'dart:async';
import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:go_router/go_router.dart';
import 'package:supabase_flutter/supabase_flutter.dart';

import 'package:nutrient_earth_client/core/services/auth_service.dart';
import 'package:nutrient_earth_client/routing/app_router.dart';

class MockControlledAuthService implements AuthService {
  User? _user;
  Session? _session;
  final StreamController<AuthState> _authController = StreamController<AuthState>.broadcast();
  bool resetPasswordCalled = false;
  String? lastResetEmail;
  bool updatePasswordCalled = false;
  String? lastUpdatedPassword;

  void setAuthenticatedUser(String email, {String id = 'usr_mock_123'}) {
    _user = User(
      id: id,
      appMetadata: {},
      userMetadata: {},
      aud: 'authenticated',
      createdAt: DateTime.now().toIso8601String(),
      email: email,
    );
    _session = Session(
      accessToken: 'mock_token_jwt',
      tokenType: 'bearer',
      user: _user!,
    );
    _authController.add(AuthState(AuthChangeEvent.signedIn, _session));
  }

  void clearSession() {
    _user = null;
    _session = null;
    _authController.add(const AuthState(AuthChangeEvent.signedOut, null));
  }

  void dispose() {
    _authController.close();
  }

  @override
  User? get currentUser => _user;

  @override
  Session? get currentSession => _session;

  @override
  bool get isAuthenticated => _user != null;

  @override
  Stream<AuthState> get authStateChanges => _authController.stream;

  @override
  Future<AuthResponse> signUp({
    required String email,
    required String password,
    Map<String, dynamic>? data,
  }) async {
    setAuthenticatedUser(email);
    return AuthResponse(session: _session, user: _user);
  }

  @override
  Future<AuthResponse> signIn({
    required String email,
    required String password,
  }) async {
    setAuthenticatedUser(email);
    return AuthResponse(session: _session, user: _user);
  }

  @override
  Future<bool> signInWithGoogle() async {
    setAuthenticatedUser('google_user@example.com');
    return true;
  }

  @override
  Future<void> signOut() async {
    clearSession();
  }

  @override
  Future<void> resetPasswordForEmail({required String email}) async {
    resetPasswordCalled = true;
    lastResetEmail = email;
  }

  @override
  Future<UserResponse> updatePassword({required String newPassword}) async {
    updatePasswordCalled = true;
    lastUpdatedPassword = newPassword;
    return UserResponse.fromJson({
      'user': _user?.toJson() ?? {},
    });
  }
}

class MockBuildContext extends Fake implements BuildContext {}

GoRouterState _createState(GoRouter router, String location) {
  final uri = Uri.parse(location);
  return GoRouterState(
    router.configuration,
    uri: uri,
    matchedLocation: uri.path,
    fullPath: uri.path,
    pathParameters: const {},
    pageKey: const ValueKey('test_key'),
  );
}

void main() {
  TestWidgetsFlutterBinding.ensureInitialized();

  late MockControlledAuthService mockAuth;

  setUp(() {
    mockAuth = MockControlledAuthService();
  });

  tearDown(() {
    mockAuth.dispose();
  });

  group('Supabase Auth & Reactive State Providers', () {
    test('Unauthenticated state returns null user and false for isAuthenticated', () {
      final container = ProviderContainer(
        overrides: [
          authServiceProvider.overrideWithValue(mockAuth),
        ],
      );
      addTearDown(container.dispose);

      expect(container.read(isAuthenticatedProvider), isFalse);
      expect(container.read(currentUserProvider), isNull);
    });

    test('Authenticated state reactively reflects current user and returns true for isAuthenticated', () {
      mockAuth.setAuthenticatedUser('alex.researcher@example.com');

      final container = ProviderContainer(
        overrides: [
          authServiceProvider.overrideWithValue(mockAuth),
        ],
      );
      addTearDown(container.dispose);

      expect(container.read(isAuthenticatedProvider), isTrue);
      expect(container.read(currentUserProvider)?.email, equals('alex.researcher@example.com'));
    });

    test('Sign out updates reactive providers immediately', () async {
      mockAuth.setAuthenticatedUser('alex.researcher@example.com');

      final container = ProviderContainer(
        overrides: [
          authServiceProvider.overrideWithValue(mockAuth),
        ],
      );
      addTearDown(container.dispose);

      expect(container.read(isAuthenticatedProvider), isTrue);

      mockAuth.clearSession();
      // Allow microtask stream event to propagate through Riverpod
      await Future<void>.delayed(Duration.zero);
      expect(container.read(isAuthenticatedProvider), isFalse);
      expect(container.read(currentUserProvider), isNull);
    });

    test('Password reset and update password methods record parameters properly', () async {
      await mockAuth.resetPasswordForEmail(email: 'reset@example.com');
      expect(mockAuth.resetPasswordCalled, isTrue);
      expect(mockAuth.lastResetEmail, equals('reset@example.com'));

      await mockAuth.updatePassword(newPassword: 'newSecurePassword123');
      expect(mockAuth.updatePasswordCalled, isTrue);
      expect(mockAuth.lastUpdatedPassword, equals('newSecurePassword123'));
    });
  });

  group('GoRouter Protected Route Guards', () {
    test('GoRouterRefreshStream instantiates and cleans up listeners without errors', () {
      final refreshStream = GoRouterRefreshStream(const Stream<AuthState>.empty());
      expect(refreshStream, isA<ChangeNotifier>());
      refreshStream.dispose();
    });

    test('Default appRouter is configured with initial location and route definitions', () {
      expect(appRouter, isA<GoRouter>());
      expect(appRouter.routeInformationProvider.value.uri.path, isNotEmpty);
    });

    test('Unauthenticated user navigating to protected onboarding route is redirected to /auth with returnTo', () {
      final router = createAppRouter(authService: mockAuth);
      final state = _createState(router, '/onboarding/health-goals');

      final redirect = appRouterRedirect(
        MockBuildContext(),
        state,
        authService: mockAuth,
      );

      // Must redirect to /auth with encoded returnTo
      expect(redirect, contains('/auth?mode=signin&returnTo='));
      expect(redirect, contains(Uri.encodeComponent('/onboarding/health-goals')));
    });

    test('Unauthenticated user navigating to public routes (today, welcome, splash) is not blocked', () {
      final router = createAppRouter(authService: mockAuth);

      final stateToday = _createState(router, '/today');
      final redirectToday = appRouterRedirect(
        MockBuildContext(),
        stateToday,
        authService: mockAuth,
      );
      expect(redirectToday, isNull);

      final stateWelcome = _createState(router, '/welcome');
      final redirectWelcome = appRouterRedirect(
        MockBuildContext(),
        stateWelcome,
        authService: mockAuth,
      );
      expect(redirectWelcome, isNull);

      final stateSplash = _createState(router, '/splash');
      final redirectSplash = appRouterRedirect(
        MockBuildContext(),
        stateSplash,
        authService: mockAuth,
      );
      expect(redirectSplash, isNull);
    });

    test('Authenticated user navigating to /auth is redirected forward to /today', () {
      mockAuth.setAuthenticatedUser('member@example.com');
      final router = createAppRouter(authService: mockAuth);
      final state = _createState(router, '/auth');

      final redirect = appRouterRedirect(
        MockBuildContext(),
        state,
        authService: mockAuth,
      );

      expect(redirect, equals('/today'));
    });

    test('Authenticated user navigating to /auth with returnTo is redirected forward to returnTo', () {
      mockAuth.setAuthenticatedUser('member@example.com');
      final router = createAppRouter(authService: mockAuth);
      final state = _createState(
        router,
        '/auth?mode=signin&returnTo=%2Fonboarding%2Fdifficulties',
      );

      final redirect = appRouterRedirect(
        MockBuildContext(),
        state,
        authService: mockAuth,
      );

      expect(redirect, equals('/onboarding/difficulties'));
    });

    test('Authenticated user navigating to /welcome is redirected to /today', () {
      mockAuth.setAuthenticatedUser('member@example.com');
      final router = createAppRouter(authService: mockAuth);
      final state = _createState(router, '/welcome');

      final redirect = appRouterRedirect(
        MockBuildContext(),
        state,
        authService: mockAuth,
      );

      expect(redirect, equals('/today'));
    });
  });
}
