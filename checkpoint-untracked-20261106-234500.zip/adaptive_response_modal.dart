// ==============================================================================
// Nutrient Earth — Adaptive Response Modal
// Dynamically renders the appropriate UI template based on UniversalResponseType:
// - Conversation (Clean friendly dialog, zero evidence badges, zero citations)
// - Nutrition Knowledge (Educational botany, physiology, hydration, safe usage)
// - Clarification (Entity disambiguation chips, e.g. Apple Fruit vs Apple Inc.)
// - Nutrition Calculation (Atwater factors, calorie & macro breakdown)
// - Clinical Safety Notice (Emergency medical triage)
// - Research Synthesis / Product Analysis (Evidence dossier with live PubMed links)
// ==============================================================================

import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:url_launcher/url_launcher.dart';

import '../../../../core/design_system/tokens/ne_tokens.dart';
import '../../../../core/domain/answer_contract/universal_intelligence_answer.dart';
import 'universal_reference_answer_card.dart';

class AdaptiveResponseModal {
  AdaptiveResponseModal._();

  static void show({
    required BuildContext context,
    required UniversalIntelligenceAnswer answer,
    void Function(String selectedQuery)? onOptionSelected,
  }) {
    switch (answer.responseType) {
      case UniversalResponseType.conversation:
        _showConversationSheet(context, answer, onOptionSelected);
        break;
      case UniversalResponseType.clarification:
        _showClarificationSheet(context, answer, onOptionSelected);
        break;
      case UniversalResponseType.nutritionKnowledge:
        _showNutritionKnowledgeSheet(context, answer, onOptionSelected);
        break;
      case UniversalResponseType.nutritionCalculation:
        _showNutritionCalculationSheet(context, answer, onOptionSelected);
        break;
      case UniversalResponseType.safetyResponse:
        _showSafetyNoticeSheet(context, answer);
        break;
      case UniversalResponseType.productAnalysis:
      case UniversalResponseType.researchSynthesis:
      case UniversalResponseType.personalHealthInsight:
      case UniversalResponseType.error:
        Navigator.of(context).push(
          MaterialPageRoute(
            builder: (ctx) => UniversalReferenceAnswerCard.fromUniversalAnswer(
              answer: answer,
              onBack: () => Navigator.of(ctx).pop(),
            ),
          ),
        );
        break;
    }
  }

  // ---------------------------------------------------------------------------
  // A. Normal Conversation Template (Zero evidence badges, natural greeting)
  // ---------------------------------------------------------------------------
  static void _showConversationSheet(
    BuildContext context,
    UniversalIntelligenceAnswer answer,
    void Function(String)? onOptionSelected,
  ) {
    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      backgroundColor: Colors.transparent,
      builder: (ctx) => Container(
        decoration: const BoxDecoration(
          color: NETokens.background,
          borderRadius: BorderRadius.vertical(top: Radius.circular(24)),
        ),
        padding: const EdgeInsets.fromLTRB(20, 16, 20, 24),
        child: SafeArea(
          child: Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Center(
                child: Container(
                  width: 40,
                  height: 4,
                  decoration: BoxDecoration(
                    color: NETokens.borderDefault,
                    borderRadius: BorderRadius.circular(2),
                  ),
                ),
              ),
              const SizedBox(height: 16),
              Row(
                children: [
                  Container(
                    width: 32,
                    height: 32,
                    decoration: BoxDecoration(
                      shape: BoxShape.circle,
                      color: NETokens.surfaceContainer,
                      border: Border.all(color: NETokens.borderDefault),
                    ),
                    child: const Icon(Icons.chat_bubble_outline_rounded, size: 16, color: NETokens.forest),
                  ),
                  const SizedBox(width: 10),
                  Text(
                    'Nutrient Earth',
                    style: GoogleFonts.manrope(
                      fontSize: 14,
                      fontWeight: FontWeight.w700,
                      color: NETokens.darkEvergreen,
                    ),
                  ),
                  const Spacer(),
                  IconButton(
                    icon: const Icon(Icons.close_rounded, size: 20, color: NETokens.textSecondary),
                    onPressed: () => Navigator.of(ctx).pop(),
                  ),
                ],
              ),
              const SizedBox(height: 12),
              Text(
                answer.heroAnswer,
                style: GoogleFonts.newsreader(
                  fontSize: 22,
                  fontWeight: FontWeight.w600,
                  color: NETokens.darkEvergreen,
                ),
              ),
              const SizedBox(height: 10),
              Text(
                answer.recommendation,
                style: GoogleFonts.manrope(
                  fontSize: 14,
                  fontWeight: FontWeight.w400,
                  color: NETokens.darkEvergreen,
                  height: 1.45,
                ),
              ),
              if (answer.practicalSteps.isNotEmpty) ...[
                const SizedBox(height: 18),
                Text(
                  'Suggested inquiries:',
                  style: GoogleFonts.manrope(
                    fontSize: 12,
                    fontWeight: FontWeight.w600,
                    color: NETokens.textSecondary,
                  ),
                ),
                const SizedBox(height: 8),
                Wrap(
                  spacing: 8,
                  runSpacing: 8,
                  children: answer.practicalSteps.map((step) {
                    final cleanQuery = step
                        .replaceAll('Ask a nutrition question (e.g. "', '')
                        .replaceAll('Research a supplement or nutrient (e.g. "', '')
                        .replaceAll('")', '')
                        .replaceAll('"', '');

                    return ActionChip(
                      backgroundColor: Colors.white,
                      side: const BorderSide(color: NETokens.borderDefault),
                      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(20)),
                      label: Text(
                        cleanQuery,
                        style: GoogleFonts.manrope(
                          fontSize: 12,
                          fontWeight: FontWeight.w600,
                          color: NETokens.forest,
                        ),
                      ),
                      onPressed: () {
                        Navigator.of(ctx).pop();
                        onOptionSelected?.call(cleanQuery);
                      },
                    );
                  }).toList(),
                ),
              ],
            ],
          ),
        ),
      ),
    );
  }

  // ---------------------------------------------------------------------------
  // B. General Nutrition Knowledge Template (Isabgol)
  // ---------------------------------------------------------------------------
  static void _showNutritionKnowledgeSheet(
    BuildContext context,
    UniversalIntelligenceAnswer answer,
    void Function(String)? onOptionSelected,
  ) {
    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      backgroundColor: Colors.transparent,
      builder: (ctx) => Container(
        constraints: BoxConstraints(maxHeight: MediaQuery.sizeOf(context).height * 0.85),
        decoration: const BoxDecoration(
          color: NETokens.background,
          borderRadius: BorderRadius.vertical(top: Radius.circular(24)),
        ),
        padding: const EdgeInsets.fromLTRB(20, 16, 20, 24),
        child: SingleChildScrollView(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Center(
                child: Container(
                  width: 40,
                  height: 4,
                  decoration: BoxDecoration(
                    color: NETokens.borderDefault,
                    borderRadius: BorderRadius.circular(2),
                  ),
                ),
              ),
              const SizedBox(height: 16),
              Row(
                children: [
                  Container(
                    padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
                    decoration: BoxDecoration(
                      color: NETokens.surfaceContainer,
                      borderRadius: BorderRadius.circular(8),
                      border: Border.all(color: NETokens.borderDefault),
                    ),
                    child: Text(
                      'NUTRITION KNOWLEDGE',
                      style: GoogleFonts.manrope(
                        fontSize: 10,
                        fontWeight: FontWeight.w700,
                        color: NETokens.forest,
                        letterSpacing: 0.8,
                      ),
                    ),
                  ),
                  const Spacer(),
                  IconButton(
                    icon: const Icon(Icons.close_rounded, size: 20, color: NETokens.textSecondary),
                    onPressed: () => Navigator.of(ctx).pop(),
                  ),
                ],
              ),
              const SizedBox(height: 12),
              Text(
                answer.heroAnswer,
                style: GoogleFonts.newsreader(
                  fontSize: 24,
                  fontWeight: FontWeight.w600,
                  color: NETokens.darkEvergreen,
                ),
              ),
              const SizedBox(height: 14),
              Container(
                padding: const EdgeInsets.all(14),
                decoration: BoxDecoration(
                  color: Colors.white,
                  borderRadius: BorderRadius.circular(14),
                  border: Border.all(color: NETokens.borderDefault),
                ),
                child: Text(
                  answer.detailedExplanation,
                  style: GoogleFonts.manrope(
                    fontSize: 13.5,
                    fontWeight: FontWeight.w400,
                    color: NETokens.darkEvergreen,
                    height: 1.5,
                  ),
                ),
              ),
              const SizedBox(height: 16),
              if (answer.evidence.hasVerifiedSources && answer.evidence.citations.isNotEmpty) ...[
                Text(
                  'Scientific Source',
                  style: GoogleFonts.manrope(
                    fontSize: 12,
                    fontWeight: FontWeight.w700,
                    color: NETokens.forest,
                  ),
                ),
                const SizedBox(height: 8),
                ...answer.evidence.citations.map((src) => Container(
                      padding: const EdgeInsets.all(12),
                      margin: const EdgeInsets.only(bottom: 8),
                      decoration: BoxDecoration(
                        color: const Color(0xFFF9FAFB),
                        borderRadius: BorderRadius.circular(12),
                        border: Border.all(color: const Color(0xFFE5E7EB)),
                      ),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(
                            src.title,
                            style: GoogleFonts.manrope(
                              fontSize: 12.5,
                              fontWeight: FontWeight.w600,
                              color: const Color(0xFF111827),
                            ),
                          ),
                          const SizedBox(height: 4),
                          Text(
                            src.authorsOrJournal,
                            style: GoogleFonts.manrope(fontSize: 11, color: const Color(0xFF6B7280)),
                          ),
                          if (src.pmid != null) ...[
                            const SizedBox(height: 6),
                            InkWell(
                              onTap: () async {
                                final clean = src.pmid!.replaceAll(RegExp(r'[^0-9]'), '');
                                final uri = Uri.parse('https://pubmed.ncbi.nlm.nih.gov/$clean/');
                                if (await canLaunchUrl(uri)) {
                                  await launchUrl(uri, mode: LaunchMode.externalApplication);
                                }
                              },
                              child: Text(
                                'PMID: ${src.pmid} ↗',
                                style: GoogleFonts.jetBrainsMono(
                                  fontSize: 11,
                                  fontWeight: FontWeight.w600,
                                  color: const Color(0xFF1B5E20),
                                  decoration: TextDecoration.underline,
                                ),
                              ),
                            ),
                          ],
                        ],
                      ),
                    )),
              ],
            ],
          ),
        ),
      ),
    );
  }

  // ---------------------------------------------------------------------------
  // C. Clarification Template (Apple Fruit vs Company)
  // ---------------------------------------------------------------------------
  static void _showClarificationSheet(
    BuildContext context,
    UniversalIntelligenceAnswer answer,
    void Function(String)? onOptionSelected,
  ) {
    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      backgroundColor: Colors.transparent,
      builder: (ctx) => Container(
        decoration: const BoxDecoration(
          color: NETokens.background,
          borderRadius: BorderRadius.vertical(top: Radius.circular(24)),
        ),
        padding: const EdgeInsets.fromLTRB(20, 16, 20, 24),
        child: SafeArea(
          child: Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Center(
                child: Container(
                  width: 40,
                  height: 4,
                  decoration: BoxDecoration(
                    color: NETokens.borderDefault,
                    borderRadius: BorderRadius.circular(2),
                  ),
                ),
              ),
              const SizedBox(height: 16),
              Row(
                children: [
                  Container(
                    padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
                    decoration: BoxDecoration(
                      color: NETokens.surfaceContainer,
                      borderRadius: BorderRadius.circular(8),
                      border: Border.all(color: NETokens.borderDefault),
                    ),
                    child: Text(
                      'CLARIFICATION',
                      style: GoogleFonts.manrope(
                        fontSize: 10,
                        fontWeight: FontWeight.w700,
                        color: NETokens.forest,
                        letterSpacing: 0.8,
                      ),
                    ),
                  ),
                  const Spacer(),
                  IconButton(
                    icon: const Icon(Icons.close_rounded, size: 20, color: NETokens.textSecondary),
                    onPressed: () => Navigator.of(ctx).pop(),
                  ),
                ],
              ),
              const SizedBox(height: 12),
              Text(
                answer.heroAnswer,
                style: GoogleFonts.newsreader(
                  fontSize: 22,
                  fontWeight: FontWeight.w600,
                  color: NETokens.darkEvergreen,
                ),
              ),
              const SizedBox(height: 10),
              Text(
                answer.detailedExplanation,
                style: GoogleFonts.manrope(
                  fontSize: 13.5,
                  fontWeight: FontWeight.w400,
                  color: NETokens.darkEvergreen,
                  height: 1.4,
                ),
              ),
              const SizedBox(height: 20),
              ...answer.clarificationOptions.map((opt) => Container(
                    width: double.infinity,
                    margin: const EdgeInsets.only(bottom: 10),
                    child: OutlinedButton(
                      style: OutlinedButton.styleFrom(
                        padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 14),
                        side: const BorderSide(color: NETokens.forest, width: 1.2),
                        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
                        alignment: Alignment.centerLeft,
                      ),
                      onPressed: () {
                        Navigator.of(ctx).pop();
                        onOptionSelected?.call(opt);
                      },
                      child: Row(
                        children: [
                          Expanded(
                            child: Text(
                              opt,
                              style: GoogleFonts.manrope(
                                fontSize: 13.5,
                                fontWeight: FontWeight.w600,
                                color: NETokens.forest,
                              ),
                            ),
                          ),
                          const Icon(Icons.arrow_forward_ios_rounded, size: 14, color: NETokens.forest),
                        ],
                      ),
                    ),
                  )),
            ],
          ),
        ),
      ),
    );
  }

  // ---------------------------------------------------------------------------
  // D. Nutrition Calculation Template (2 Eggs)
  // ---------------------------------------------------------------------------
  static void _showNutritionCalculationSheet(
    BuildContext context,
    UniversalIntelligenceAnswer answer,
    void Function(String)? onOptionSelected,
  ) {
    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      backgroundColor: Colors.transparent,
      builder: (ctx) => Container(
        decoration: const BoxDecoration(
          color: NETokens.background,
          borderRadius: BorderRadius.vertical(top: Radius.circular(24)),
        ),
        padding: const EdgeInsets.fromLTRB(20, 16, 20, 24),
        child: SafeArea(
          child: Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Center(
                child: Container(
                  width: 40,
                  height: 4,
                  decoration: BoxDecoration(
                    color: NETokens.borderDefault,
                    borderRadius: BorderRadius.circular(2),
                  ),
                ),
              ),
              const SizedBox(height: 16),
              Row(
                children: [
                  Container(
                    padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
                    decoration: BoxDecoration(
                      color: NETokens.surfaceContainer,
                      borderRadius: BorderRadius.circular(8),
                      border: Border.all(color: NETokens.borderDefault),
                    ),
                    child: Text(
                      'DETERMINISTIC NUTRITION MATH',
                      style: GoogleFonts.manrope(
                        fontSize: 10,
                        fontWeight: FontWeight.w700,
                        color: NETokens.forest,
                        letterSpacing: 0.8,
                      ),
                    ),
                  ),
                  const Spacer(),
                  IconButton(
                    icon: const Icon(Icons.close_rounded, size: 20, color: NETokens.textSecondary),
                    onPressed: () => Navigator.of(ctx).pop(),
                  ),
                ],
              ),
              const SizedBox(height: 12),
              Text(
                answer.heroAnswer,
                style: GoogleFonts.newsreader(
                  fontSize: 22,
                  fontWeight: FontWeight.w600,
                  color: NETokens.darkEvergreen,
                ),
              ),
              const SizedBox(height: 14),
              Container(
                padding: const EdgeInsets.all(14),
                decoration: BoxDecoration(
                  color: Colors.white,
                  borderRadius: BorderRadius.circular(14),
                  border: Border.all(color: NETokens.borderDefault),
                ),
                child: Text(
                  answer.detailedExplanation,
                  style: GoogleFonts.manrope(
                    fontSize: 13,
                    fontWeight: FontWeight.w400,
                    color: NETokens.darkEvergreen,
                    height: 1.5,
                  ),
                ),
              ),
              const SizedBox(height: 14),
              Text(
                answer.recommendation,
                style: GoogleFonts.manrope(
                  fontSize: 13,
                  fontWeight: FontWeight.w600,
                  color: NETokens.forest,
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  // ---------------------------------------------------------------------------
  // E. Clinical Safety Notice Template (Emergency Medical Triage)
  // ---------------------------------------------------------------------------
  static void _showSafetyNoticeSheet(BuildContext context, UniversalIntelligenceAnswer answer) {
    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      backgroundColor: Colors.transparent,
      builder: (ctx) => Container(
        decoration: const BoxDecoration(
          color: Color(0xFFFEF2F2),
          borderRadius: BorderRadius.vertical(top: Radius.circular(24)),
        ),
        padding: const EdgeInsets.fromLTRB(20, 16, 20, 24),
        child: SafeArea(
          child: Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Center(
                child: Container(
                  width: 40,
                  height: 4,
                  decoration: BoxDecoration(
                    color: const Color(0xFFFCA5A5),
                    borderRadius: BorderRadius.circular(2),
                  ),
                ),
              ),
              const SizedBox(height: 16),
              Row(
                children: [
                  const Icon(Icons.warning_amber_rounded, size: 24, color: Color(0xFFDC2626)),
                  const SizedBox(width: 8),
                  Text(
                    'CLINICAL SAFETY NOTICE',
                    style: GoogleFonts.manrope(
                      fontSize: 12,
                      fontWeight: FontWeight.w800,
                      color: const Color(0xFFDC2626),
                      letterSpacing: 0.8,
                    ),
                  ),
                  const Spacer(),
                  IconButton(
                    icon: const Icon(Icons.close_rounded, size: 20, color: Color(0xFF991B1B)),
                    onPressed: () => Navigator.of(ctx).pop(),
                  ),
                ],
              ),
              const SizedBox(height: 12),
              Text(
                answer.heroAnswer,
                style: GoogleFonts.newsreader(
                  fontSize: 22,
                  fontWeight: FontWeight.w700,
                  color: const Color(0xFF7F1D1D),
                ),
              ),
              const SizedBox(height: 10),
              Text(
                answer.detailedExplanation,
                style: GoogleFonts.manrope(
                  fontSize: 13.5,
                  fontWeight: FontWeight.w500,
                  color: const Color(0xFF991B1B),
                  height: 1.45,
                ),
              ),
              const SizedBox(height: 18),
              SizedBox(
                width: double.infinity,
                child: ElevatedButton.icon(
                  style: ElevatedButton.styleFrom(
                    backgroundColor: const Color(0xFFDC2626),
                    foregroundColor: Colors.white,
                    padding: const EdgeInsets.symmetric(vertical: 14),
                    shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
                  ),
                  icon: const Icon(Icons.phone_in_talk_rounded, size: 18),
                  label: const Text('Contact Emergency Medical Services'),
                  onPressed: () async {
                    final uri = Uri.parse('tel:911');
                    if (await canLaunchUrl(uri)) {
                      await launchUrl(uri);
                    }
                  },
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
